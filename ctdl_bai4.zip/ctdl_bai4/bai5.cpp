#include <bits/stdc++.h>
// lam bai khong co ke hoach, khong tot
// chua xay dung cmp(sinhvien, masinhvien)
#define t SinhVien
#define ll LinkedList
#define all(v) begin(v), end(v)
using namespace std;
class SinhVien
{
    friend class LopSinhVien;
    string MaSinhVien, HoTen, Lop, NgaySinh;
    double DTB;

public:
    SinhVien(string masinhvien = "", string hoten = "", string lop = "", string ngaysinh = "", double dtb = 0) : MaSinhVien(masinhvien), HoTen(hoten), Lop(lop), NgaySinh(ngaysinh), DTB(dtb) {}
    friend istream &operator>>(istream &is, SinhVien &sv)
    {
        is >> sv.MaSinhVien;
        getline(is, sv.HoTen);
        cin.ignore(0);
        is >> sv.NgaySinh;
        is >> sv.DTB;
        return is;
    }
    static SinhVien createSV()
    {
        SinhVien a;
        cin >> a;
        return a;
    }
    double getDTB()
    {
        return DTB;
    }
    void setDTB(double diem)
    {
        DTB = diem;
    }
    string getMaSinhVien()
    {
        return MaSinhVien;
    }
    friend bool operator==(SinhVien a, SinhVien b)
    {
        return a.MaSinhVien == b.MaSinhVien;
    }
    friend ostream &operator<<(ostream &os, SinhVien sv)
    {
        cout << setw(30) << " ma sinh vien: " << sv.MaSinhVien << "\n";
        cout << setw(30) << " ho ten: " << sv.HoTen << "\n";
        cout << setw(30) << " lop: " << sv.Lop << "\n";
        cout << setw(30) << " ngay sinh: " << sv.NgaySinh << "\n";
        cout << setw(30) << " diem trung binh: " << sv.DTB << "\n";
        return os;
    }
    friend bool operator<(SinhVien a, SinhVien b)
    {
        return a.DTB < b.DTB;
    }
};

struct Node
{
    Node *Next;
    t Value;
    Node(t value) : Value(value), Next(NULL) {}
    Node(t value, Node *next) : Value(value), Next(next) {}
    static Node *createNode(t value)
    {
        return new Node(value);
    }
    Node *addAfter(t value)
    {
        auto node = createNode(value);
        node->Next = Next;
        Next = node;
        return node;
    }
    void deleteAfter()
    {
        auto tmp = Next;
        Next = Next->Next;
        delete tmp;
    }
};
struct LinkedList
{
    Node *First, *Last;
    LinkedList() : First(NULL), Last(NULL) {}
    Node *addFirst(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            node->Next = First;
            First = node;
        }
        return node;
    }
    Node *addLast(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            Last->Next = node;
            Last = node;
        }
        return node;
    }
    Node *move(Node *node, unsigned int k)
    {
        while (k)
        {
            if (node->Next == NULL)
            {
                node = First;
                k--;
            }
            while (k && node->Next != NULL)
            {
                node = node->Next;
                k--;
            }
        }
        return node;
    }
    Node *search(t value)
    {
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Value == value)
                return node;
        }
        return NULL;
    }
    Node *search_before(t value)
    {
        if (First->Value == value)
            return new Node({}, First);
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Next->Value == value)
                return node;
        }
        return NULL;
    }
    int getLength()
    {
        int cnt = 0;
        for (Node *node = First; node->Next != NULL; node = node->Next, cnt++)
            ;
        return cnt;
    }
    vector<t> getList()
    {
        vector<t> vec;
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            vec.push_back(node->Value);
        }
        return vec;
    }
    void sort()
    {
        for (auto node = First; node->Next != NULL; node = node->Next)
        {
            for (auto walker = node->Next; walker->Next != NULL; walker = walker->Next)
            {
                if (walker->Value < node->Value)
                {
                    t tmp = node->Value;
                    node->Value = walker->Value;
                    walker->Value = tmp;
                }
            }
        }
    }
    void reverse_ll()
    {
        auto vec = getList();

        reverse(begin(vec), end(vec));
        int i = 0;
        for (auto node = First; node->Next != NULL; node = node->Next, i++)
            node->Value = vec[i];
    }
    void deleteFirst()
    {
        auto tmp = First;
        First = First->Next;
        delete tmp;
    }
    ll *operator()(ll x)
    {
        auto l = new ll();
        for (auto it = x.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    static ll *join(ll a, ll b)
    {
        auto l = new ll();
        for (auto it = a.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        for (auto it = b.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    ll *LL_intersect(ll a, ll c)
    {
        auto v1 = a.getList();
        set<t> s1(all(v1));
        auto v2 = c.getList();
        set<t> s2(all(v2));
        set<t> v3;
        set_intersection(all(s1), all(s2), inserter(v3, v3.begin()));
        auto l = new ll();
        for (auto i : v3)
        {
            l->addLast(i);
        }
        return l;
    }
    ll *LL_union(ll a, ll c)
    {
        auto v1 = a.getList();
        set<t> s1(all(v1));
        auto v2 = c.getList();
        set<t> s2(all(v2));
        set<t> v3;
        set_union(all(s1), all(s2), inserter(v3, v3.begin()));
        auto l = new ll();
        for (auto i : v3)
        {
            l->addLast(i);
        }
        return l;
    }
    void LL_minus(ll &a, ll c)
    {
        auto v = c.getList();
        for (t x : v)
        {
            while (auto it = a.search_before(x))
            {
                if (it == NULL)
                    break;
                it->deleteAfter();
            }
        }
    }
};
class LopSinhVien
{

    LinkedList DanhSach;

public:
    LopSinhVien()
    {
        DanhSach = ll();
    }
    Node *getFirst()
    {
        return DanhSach.First;
    }
    Node *getLast()
    {
        return DanhSach.Last;
    }

    friend void a(LopSinhVien &);
    friend void b(LopSinhVien &);
    friend void c(LopSinhVien &, double scale);
    friend void d(LopSinhVien &, string masv);
    friend void e(LopSinhVien &);         // chon truc tiep
    friend void f(LopSinhVien &, string); // binary search
    friend void g(LopSinhVien &, string); // xoas sinh vienn
    friend void h(LopSinhVien &, string, double diem);
};

void a(LopSinhVien &lsv)
{
    int soluong;
    cin >> soluong;
    for (int i = 1; i <= soluong; ++i)
    {
        lsv.DanhSach.addLast(SinhVien::createSV());
    }
}
void b(LopSinhVien lsv)
{
    Node *sv = lsv.getFirst();
    for (; sv->Next != NULL; sv = sv->Next)
    {
        cout << sv->Value;
    }
}
void c(LopSinhVien &lsv, double scale = 5)
{
    Node *it = lsv.getFirst();
    for (; it->Next != NULL; it = it->Next)
    {
        if (it->Value.getDTB() > scale)
        {
            cout << it->Value;
        }
    }
}
void d(LopSinhVien &lsv, string masv)
{
    Node *it = lsv.getFirst();
    for (; it->Next != NULL; it = it->Next)
    {
        if (it->Value.getMaSinhVien() == masv)
        {
            cout << it->Value;
        }
    }
}
void e(LopSinhVien &lsv)
{                            // chon truc tiep selectionsort
    lsv.DanhSach.ll::sort(); // su dung selectionsort
}
void f(LopSinhVien &lsv, string masv)
{ // binary search
    // binary theo kieu #2
    int sz = lsv.DanhSach.getLength();
    int len = sz;
    int pos = 0;
    auto it = lsv.DanhSach.First;
    for (sz = sz / 2; sz > 0 && pos < len; sz /= 2)
    {
        if (pos + sz >= len)
            continue;
        auto it2 = it;
        lsv.DanhSach.move(it2, sz);
        if (it2->Value.getMaSinhVien() == masv)
        {
            cout << it2->Value;
            return;
        }
        else if (it2->Value.getMaSinhVien() < masv)
        {
            it = it2;
            pos += sz;
        }
        else
        {
            continue;
        }
    }
    cout << "khong co sinh vien nao !\n";
}

void g(LopSinhVien &lsv, string masv) // xoas sinh vienn
{
    if (lsv.getFirst()->Value.getMaSinhVien() == masv)
    {
        lsv.DanhSach.deleteFirst();
        return;
    }
    for (auto it = lsv.getFirst(); it != lsv.getLast(); it = it->Next)
    {
        if (it->Next->Value.getMaSinhVien() == masv)
        {
            it->deleteAfter();
        }
    }
}

void h(LopSinhVien &lsv, string masv, double diem)
{
    for (auto it = lsv.getFirst(); it != NULL; it = it->Next)
    {
        if (it->Value.getMaSinhVien() == masv)
        {
            it->Value.setDTB(diem);
            return;
        }
    }
}

int main()
{
}