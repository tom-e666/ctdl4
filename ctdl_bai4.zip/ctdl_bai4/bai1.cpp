#include <bits/stdc++.h>
#define t int
using namespace std;
struct Node
{
    Node *Next;
    t Value;
    Node(t value) : Value(value), Next(NULL) {}
    static Node *createNode(t value)
    {
        return new Node(value);
    }
    Node *addAfter(t value)
    {
        auto node = createNode(value);
        node->Next = Next;
        Next = node;
        return node;
    }
    Node *deleteAfter()
    {
        auto tmp = Next;
        Next = Next->Next;
        delete tmp;
        return this;
    }
};
struct LinkedList
{
    Node *First, *Last;
    LinkedList() : First(NULL), Last(NULL) {}
    Node *addFirst(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            node->Next = First;
            First = node;
        }
        return node;
    }
    Node *addLast(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            Last->Next = node;
            Last = node;
        }
        return node;
    }
    Node *move(Node *node, unsigned int k)
    {
        while (k)
        {
            if (node->Next == NULL)
            {
                node = First;
                k--;
            }
            while (k && node->Next != NULL)
            {
                node = node->Next;
                k--;
            }
        }
        return node;
    }
    Node *search(t value)
    {
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Value == value)
                return node;
        }
        return NULL;
    }
    int getLength()
    {
        int cnt = 0;
        for (Node *node = First; node->Next != NULL; node = node->Next, cnt++)
            ;
        return cnt;
    }
    vector<t> getList()
    {
        vector<t> vec;
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            vec.push_back(node->Value);
        }
        return vec;
    }
    void sort()
    {
        for (auto node = First; node->Next != NULL; node = node->Next)
        {
            for (auto walker = node->Next; walker->Next != NULL; walker = walker->Next)
            {
                if (walker->Value < node->Value)
                {
                    t tmp = node->Value;
                    node->Value = walker->Value;
                    walker->Value = tmp;
                }
            }
        }
    }
    void reverse_ll()
    {
        auto vec = getList();

        reverse(begin(vec), end(vec));
        int i = 0;
        for (auto node = First; node->Next != NULL; node = node->Next, i++)
            node->Value = vec[i];
    }
    void deleteFirst()
    {
        auto tmp = First;
        First = First->Next;
        delete tmp;
    }
};
inline void a()
{
    LinkedList ds;
    fstream f("bai1.txt");
    int k;
    while (f >> k)
    {
        ds.addLast(k);
    }
}
void b(LinkedList &l)
{
    auto v = l.getList();
    for (t x : v)
    {
        cout << x << " ";
    }
    cout << '\n';
}
inline void c(LinkedList ds)
{
    auto vec = ds.getList();
    vector<t> ans(100);
    copy_if(begin(vec), end(vec), begin(ans), [](int x)
            {
		if (x == 2) return true;
		if (x < 2) return false;
		for (int i = 2; i <= sqrt(x); ++i) {
			if (x % i == 2) return false;
		}
		return true; });
    for (t x : ans)
    {
        cout << x << " ";
    }
    cout << '\n';
}
inline void d(LinkedList &l)
{
    auto v = l.getList();
    double sum = 0;
    int cnt = 0;
    for (t x : v)
    {
        sum += x;
        cnt++;
    }
    cout << sum / cnt << '\n';
}
void e(LinkedList &l, t value)
{
    auto v = l.getList();
    cout << count_if(begin(v), end(v), [=](t vl)
                     { return vl == value; });
}
int f(LinkedList &l, t e)
{
    auto v = l.getList();
    sort(begin(v), end(v), greater<int>());
    for (int x : v)
    {
        if (sqrt(x) * sqrt(x) == x)
        {
            return x;
        }
    }
    return -1;
}
t g(LinkedList &l, int k)
{
    auto walker = l.First;
    l.move(walker, k - 1);
    return walker->Value;
}
t h(LinkedList &l)
{
    auto v = l.getList();
    sort(begin(v), end(v));

    return v[0];
}
void i(LinkedList &l, Node *q, t value)
{
    q->addAfter(value);
    return;
}
bool j(LinkedList &l, t value)
{
    auto v = l.getList();
    if (find(begin(v), end(v), value) != v.end())
        return 0;
    l.addLast(value);
    return 1;
}
void k(LinkedList &l, int k)
{
    if (k > l.getLength())
        return;
    for (int i = 1; i < k; ++i)
        l.First->deleteAfter();
    l.deleteFirst();
}
void l(LinkedList &l, int k)
{
    while (l.First->Value == k)
    {
        l.deleteFirst();
    }
    for (auto it = l.First; it != NULL; it = it->Next)
    {
        if (it->Next->Value == k)
            it->deleteAfter();
    }
}
void m(LinkedList &l, Node *q)
{
    q->deleteAfter();
}
void n(LinkedList &l)
{
    l.sort();
    for (auto it = l.First; it != NULL; it = it->Next)
    {
        while (it->Value == it->Next->Value)
        {
            it->deleteAfter();
        }
    }
}
void o(LinkedList &l)
{
    // interchagesort;
    for (auto it = l.First->Next; it->Next != NULL; it = it->Next)
    {
        for (auto it2 = l.First; it2 != it; it2 = it2->Next)
        {
            if (it2->Value > it2->Next->Value)
            {
                t tmp = it2->Value;
                it2->Value = it2->Next->Value;
                it2->Next->Value = tmp;
            }
        }
    }
}
void p(LinkedList &l, t value)
{
    l.sort();
    auto it = l.First;
    while (it->Next->Value < value)
        it = it->Next;
    it->addAfter(value);
}

void q(LinkedList &l)
{
    auto turnPefectNumberto0 = [](int &x)
    {
        if (x < 0)
            return;
        if (x == 1 || x == 0)
        {
            x = 0;
            return;
        }
        int sum = 0;
        for (int i = 1; i <= (x + 1) / 2; ++i)
        {
            if (x % i == 0)
                sum += i;
        }
        if (sum == x)
        {
            x = 0;
        }
        return;
    };
}

int main()
{
}