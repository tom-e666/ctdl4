#include <bits/stdc++.h>
#define t int
#define ll LinkedList
#define all(v) begin(v), end(v)
using namespace std;
struct Node
{
    Node *Next;
    t Value;
    Node(t value) : Value(value), Next(NULL) {}
    Node(t value, Node *next) : Value(value), Next(next) {}
    static Node *createNode(t value)
    {
        return new Node(value);
    }
    Node *addAfter(t value)
    {
        auto node = createNode(value);
        node->Next = Next;
        Next = node;
        return node;
    }
    void deleteAfter()
    {
        auto tmp = Next;
        Next = Next->Next;
        delete tmp;
    }
};
struct LinkedList
{
    Node *First, *Last;
    LinkedList() : First(NULL), Last(NULL) {}
    Node *addFirst(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            node->Next = First;
            First = node;
        }
        return node;
    }
    Node *addLast(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            Last->Next = node;
            Last = node;
        }
        return node;
    }
    Node *move(Node *node, unsigned int k)
    {
        while (k)
        {
            if (node->Next == NULL)
            {
                node = First;
                k--;
            }
            while (k && node->Next != NULL)
            {
                node = node->Next;
                k--;
            }
        }
        return node;
    }
    Node *search(t value)
    {
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Value == value)
                return node;
        }
        return NULL;
    }
    Node *search_before(t value)
    {
        if (First->Value == value)
            return new Node(0, First);
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Next->Value == value)
                return node;
        }
        return NULL;
    }
    int getLength()
    {
        int cnt = 0;
        for (Node *node = First; node->Next != NULL; node = node->Next, cnt++)
            ;
        return cnt;
    }
    vector<t> getList()
    {
        vector<t> vec;
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            vec.push_back(node->Value);
        }
        return vec;
    }
    void sort()
    {
        for (auto node = First; node->Next != NULL; node = node->Next)
        {
            for (auto walker = node->Next; walker->Next != NULL; walker = walker->Next)
            {
                if (walker->Value < node->Value)
                {
                    t tmp = node->Value;
                    node->Value = walker->Value;
                    walker->Value = tmp;
                }
            }
        }
    }
    void reverse_ll()
    {
        auto vec = getList();

        reverse(begin(vec), end(vec));
        int i = 0;
        for (auto node = First; node->Next != NULL; node = node->Next, i++)
            node->Value = vec[i];
    }
    void deleteFirst()
    {
        auto tmp = First;
        First = First->Next;
        delete tmp;
    }
    ll *operator()(ll x)
    {
        auto l = new ll();
        for (auto it = x.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    static ll *join(ll a, ll b)
    {
        auto l = new ll();
        for (auto it = a.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        for (auto it = b.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
};

ll *LL_intersect(ll a, ll c)
{
    auto v1 = a.getList();
    set<t> s1(all(v1));
    auto v2 = c.getList();
    set<t> s2(all(v2));
    set<t> v3;
    set_intersection(all(s1), all(s2), inserter(v3, v3.begin()));
    auto l = new ll();
    for (auto i : v3)
    {
        l->addLast(i);
    }
    return l;
}
ll *LL_union(ll a, ll c)
{
    auto v1 = a.getList();
    set<t> s1(all(v1));
    auto v2 = c.getList();
    set<t> s2(all(v2));
    set<t> v3;
    set_union(all(s1), all(s2), inserter(v3, v3.begin()));
    auto l = new ll();
    for (auto i : v3)
    {
        l->addLast(i);
    }
    return l;
}
void LL_minus(ll &a, ll c)
{
    auto v = c.getList();
    for (t x : v)
    {
        while (auto it = a.search_before(x))
        {
            if (it == NULL)
                break;
            it->deleteAfter();
        }
    }
}
ll &a(ll &a, ll b)
{
    LL_minus(a, b);
    return a;
}
ll *b(ll a, ll b)
{
    auto l = LL_intersect(a, b);
    l->sort();
    return l;
}
ll *c(ll a, ll b)
{
    auto l = LL_union(a, b);
    l->sort();
    return l;
}
int main()
{
}