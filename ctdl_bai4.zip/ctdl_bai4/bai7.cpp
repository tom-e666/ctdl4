#include <bits/stdc++.h>

// because using pair, the comparator does not perform well
#define ll LinkedList
#define all(v) begin(v), end(v)
using namespace std;
bool cmp(pair<int, int> a, pair<int, int> b)
{
    return a.second > b.second;
}
#define t pair<int, int>
struct Node
{
    Node *Next;
    t Value;
    Node(t value) : Value(value), Next(NULL) {}
    Node(t value, Node *next) : Value(value), Next(next) {}
    static Node *createNode(t value)
    {
        return new Node(value);
    }
    Node *addAfter(t value)
    {
        auto node = createNode(value);
        node->Next = Next;
        Next = node;
        return node;
    }
    void deleteAfter()
    {
        auto tmp = Next;
        Next = Next->Next;
        delete tmp;
    }
};
struct LinkedList
{
    Node *First, *Last;
    LinkedList() : First(NULL), Last(NULL) {}
    Node *addFirst(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            node->Next = First;
            First = node;
        }
        return node;
    }
    Node *addLast(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            Last->Next = node;
            Last = node;
        }
        return node;
    }
    Node *move(Node *node, unsigned int k)
    {
        while (k)
        {
            if (node->Next == NULL)
            {
                node = First;
                k--;
            }
            while (k && node->Next != NULL)
            {
                node = node->Next;
                k--;
            }
        }
        return node;
    }
    Node *search(t value)
    {
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Value == value)
                return node;
        }
        return NULL;
    }
    Node *search_before(t value)
    {
        if (First->Value == value)
            return new Node({}, First);
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Next->Value == value)
                return node;
        }
        return NULL;
    }
    int getLength()
    {
        int cnt = 0;
        for (Node *node = First; node->Next != NULL; node = node->Next, cnt++)
            ;
        return cnt;
    }
    vector<t> getList()
    {
        vector<t> vec;
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            vec.push_back(node->Value);
        }
        return vec;
    }
    void sort()
    {
        for (auto node = First; node->Next != NULL; node = node->Next)
        {
            for (auto walker = node->Next; walker->Next != NULL; walker = walker->Next)
            {
                if (walker->Value < node->Value)
                {
                    t tmp = node->Value;
                    node->Value = walker->Value;
                    walker->Value = tmp;
                }
            }
        }
    }
    void reverse_ll()
    {
        auto vec = getList();

        reverse(begin(vec), end(vec));
        int i = 0;
        for (auto node = First; node->Next != NULL; node = node->Next, i++)
            node->Value = vec[i];
    }
    void deleteFirst()
    {
        auto tmp = First;
        First = First->Next;
        delete tmp;
    }
    ll *operator()(ll x)
    {
        auto l = new ll();
        for (auto it = x.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    static ll *join(ll a, ll b)
    {
        auto l = new ll();
        for (auto it = a.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        for (auto it = b.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    ll *LL_intersect(ll a, ll c)
    {
        auto v1 = a.getList();
        set<t> s1(all(v1));
        auto v2 = c.getList();
        set<t> s2(all(v2));
        set<t> v3;
        set_intersection(all(s1), all(s2), inserter(v3, v3.begin()));
        auto l = new ll();
        for (auto i : v3)
        {
            l->addLast(i);
        }
        return l;
    }
    ll *LL_union(ll a, ll c)
    {
        auto v1 = a.getList();
        set<t> s1(all(v1));
        auto v2 = c.getList();
        set<t> s2(all(v2));
        set<t> v3;
        set_union(all(s1), all(s2), inserter(v3, v3.begin()));
        auto l = new ll();
        for (auto i : v3)
        {
            l->addLast(i);
        }
        return l;
    }
    void LL_minus(ll &a, ll c)
    {
        auto v = c.getList();
        for (t x : v)
        {
            while (auto it = a.search_before(x))
            {
                if (it == NULL)
                    break;
                it->deleteAfter();
            }
        }
    }
};
// class LopSinhVien
class DaThuc
{
    // Fn : pair mu-he so
    ll Fn;

public:
    DaThuc(vector<t> Heso = {})
    { // sorted
        for (auto p : Heso)
        {
            Fn.addLast(p);
        }
    }
    istream &readDaThuc(istream &f)
    { // read on line
        string s;
        getline(f, s);
        stringstream ss(s);
        int a, b;
        while (ss >> a >> b)
        {
            Fn.addLast({b, a});
        }
        return f;
    }
    ostream &inDathuc(ostream &o)
    {
        string s;
        for (auto it = Fn.First; it != NULL; ++it)
        {
            s += it->Value.second + 'x^' + it->Value.first + '+';
        }
        if (s.size())
            s.erase(s.end() - 1);
        return o;
    }
    void sort()
    {
        Fn.sort();
    }
    DaThuc tinhDaoHam()
    {
        vector<t> v;
        for (auto it = Fn.First; it != NULL; ++it)
        {
            t tmp = it->Value;
            tmp.second *= tmp.first;
            tmp.first--;
            if (tmp.second)
                v.push_back(tmp);
        }
        return DaThuc(v);
    }
    long long tinhDaThuc(long long x)
    {
        long long sum;
        for (auto it = Fn.First; it != NULL; ++it)
        {
            sum += pow(x, it->Value.second) * it->Value.first;
        }
        return sum;
    }
    static DaThuc congDaThuc(DaThuc a, DaThuc b)
    {
        a.sort();
        b.sort();
        vector<t> v;
        auto ia = a.Fn.First;
        auto ib = a.Fn.First;
        while (ia != NULL && ib != NULL)
        {
            if (ia->Value == ib->Value)
            {
                v.push_back({ia->Value.first + ib->Value.first, ia->Value.second + ib->Value.second});
                // v.push_bach(*ia + *ib);
                ia = ia->Next;
                ib = ib->Next;
            }
            else if (ia->Value < ib->Value)
            {
                v.push_back(ib->Value);
                ib = ib->Next;
            }
            else
            {
                v.push_back(ia->Value);
                ia = ia->Next;
            }
        }
        while (ia != NULL)
        {
            v.push_back(ia->Value);
            ia = ia->Next;
        }
        while (ib != NULL)
        {
            v.push_back(ib->Value);
            ib = ib->Next;
        }
        return DaThuc(v);
    }
    static DaThuc tichDaThuc(DaThuc a, DaThuc b)
    {
        vector<DaThuc> v;
        for (auto it1 = a.Fn.First; it1 != NULL; ++it1)
        {
            t aV = it1->Value;
            vector<t> tmp;
            for (auto it2 = b.Fn.First; it2 != NULL; ++it2)
                tmp.push_back({it2->Value.first * aV.first, it2->Value.second * aV.second});
            v.push_back(DaThuc(tmp));
        }
        DaThuc sum = DaThuc();
        for (auto dt : v)
        {
            sum = congDaThuc(sum, dt);
        }
        return sum;
    }
};
int main()
{
    cout << "hi";
}
