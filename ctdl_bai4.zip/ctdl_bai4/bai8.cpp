#include <bits/stdc++.h>
#define t VIDEO
#define ll LinkedList
#define all(v) begin(v), end(v)
using namespace std;
// class sinhien
class VIDEO
{
    string TenPhim, TheLoai, TenDaoDien, DVNamChinh, DVNuChinh, NamSX;

public:
    VIDEO(string tenphim = "", string theloai = "", string tendaodien = "", string dvnamchinh = "", string dvnuchinh = "", string namsv = "") : TenPhim(tenphim), TheLoai(theloai), TenDaoDien(tendaodien), DVNamChinh(DVNamChinh), DVNuChinh(dvnuchinh), NamSX(namsv) {}
    friend istream &operator>>(istream &inputFile, VIDEO &vid)
    {
        string line;
        if (getline(inputFile, line, '#'))
        {
            istringstream iss(line);

            getline(iss, vid.TenPhim, '#');
            getline(iss, vid.TheLoai, '#');
            getline(iss, vid.TenDaoDien, '#');
            getline(iss, vid.DVNamChinh, '#');
            getline(iss, vid.DVNuChinh, '#');
            getline(iss, vid.NamSX);
        }
        return inputFile;
    }

    friend ostream &operator<<(ostream &outputFile, const VIDEO &vid)
    {
        outputFile << setw(30) << "Ten Phim: " << vid.TenPhim << "\n";
        outputFile << setw(30) << "The Loai: " << vid.TheLoai << "\n";
        outputFile << setw(30) << "Ten Dao Dien: " << vid.TenDaoDien << "\n";
        outputFile << setw(30) << "Dien Vien Nam Chinh: " << vid.DVNamChinh << "\n";
        outputFile << setw(30) << "Dien Vien Nu Chinh: " << vid.DVNuChinh << "\n";
        outputFile << setw(30) << "Nam San Xuat: " << vid.NamSX << "\n";

        return outputFile;
    }
    friend bool operator==(VIDEO a, VIDEO b)
    {
        return a.TenPhim == b.TenPhim;
    }
    friend bool operator==(VIDEO a, string b)
    {
        return a.TenPhim == b;
    }
    friend bool operator<(VIDEO a, VIDEO b)
    {
        return a.TenPhim < b.TenPhim;
    }
    string getTenPhim()
    {
        return TenPhim;
    }
    string getNamSX()
    {
        return NamSX;
    }
    void setTheLoai(string s)
    {
        TheLoai = s;
    }
    string getTenDaoDien()
    {
        return TenDaoDien;
    }
};
struct Node
{
    Node *Next;
    t Value;
    Node(t value) : Value(value), Next(NULL) {}
    Node(t value, Node *next) : Value(value), Next(next) {}
    static Node *createNode(t value)
    {
        return new Node(value);
    }
    Node *addAfter(t value)
    {
        auto node = createNode(value);
        node->Next = Next;
        Next = node;
        return node;
    }
    void deleteAfter()
    {
        auto tmp = Next;
        Next = Next->Next;
        delete tmp;
    }
};
struct LinkedList
{
    Node *First, *Last;
    LinkedList() : First(NULL), Last(NULL) {}
    Node *addFirst(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            node->Next = First;
            First = node;
        }
        return node;
    }
    Node *addLast(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            Last->Next = node;
            Last = node;
        }
        return node;
    }
    Node *move(Node *node, unsigned int k)
    {
        while (k)
        {
            if (node->Next == NULL)
            {
                node = First;
                k--;
            }
            while (k && node->Next != NULL)
            {
                node = node->Next;
                k--;
            }
        }
        return node;
    }
    Node *search(t value)
    {
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Value == value)
                return node;
        }
        return NULL;
    }
    Node *search_before(t value)
    {
        if (First->Value == value)
            return new Node({}, First);
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Next->Value == value)
                return node;
        }
        return NULL;
    }
    int getLength()
    {
        int cnt = 0;
        for (Node *node = First; node->Next != NULL; node = node->Next, cnt++)
            ;
        return cnt;
    }
    vector<t> getList()
    {
        vector<t> vec;
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            vec.push_back(node->Value);
        }
        return vec;
    }
    void sort()
    {
        for (auto node = First; node->Next != NULL; node = node->Next)
        {
            for (auto walker = node->Next; walker->Next != NULL; walker = walker->Next)
            {
                if (walker->Value < node->Value)
                {
                    t tmp = node->Value;
                    node->Value = walker->Value;
                    walker->Value = tmp;
                }
            }
        }
    }
    void reverse_ll()
    {
        auto vec = getList();

        reverse(begin(vec), end(vec));
        int i = 0;
        for (auto node = First; node->Next != NULL; node = node->Next, i++)
            node->Value = vec[i];
    }
    void deleteFirst()
    {
        auto tmp = First;
        First = First->Next;
        delete tmp;
    }
    ll *operator()(ll x)
    {
        auto l = new ll();
        for (auto it = x.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    static ll *join(ll a, ll b)
    {
        auto l = new ll();
        for (auto it = a.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        for (auto it = b.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    ll *LL_intersect(ll a, ll c)
    {
        auto v1 = a.getList();
        set<t> s1(all(v1));
        auto v2 = c.getList();
        set<t> s2(all(v2));
        set<t> v3;
        set_intersection(all(s1), all(s2), inserter(v3, v3.begin()));
        auto l = new ll();
        for (auto i : v3)
        {
            l->addLast(i);
        }
        return l;
    }
    ll *LL_union(ll a, ll c)
    {
        auto v1 = a.getList();
        set<t> s1(all(v1));
        auto v2 = c.getList();
        set<t> s2(all(v2));
        set<t> v3;
        set_union(all(s1), all(s2), inserter(v3, v3.begin()));
        auto l = new ll();
        for (auto i : v3)
        {
            l->addLast(i);
        }
        return l;
    }
    void LL_minus(ll &a, ll c)
    {
        auto v = c.getList();
        for (t x : v)
        {
            while (auto it = a.search_before(x))
            {
                if (it == NULL)
                    break;
                it->deleteAfter();
            }
        }
    }
    Node *getFirst()
    {
        return First;
    }
};

class QLPhim
{
    ll DS;

public:
    QLPhim()
    {
        DS = ll();
    }
    istream &themPhim(istream &is)
    {
        int n;
        is >> n;
        VIDEO vid;
        for (int i = 1; i <= n; ++i)
        {
            is >> vid;
            DS.addLast(vid);
        }
        return is;
    }
    ostream &xuatPhim(ostream &os)
    {
        for (auto phim = DS.First; phim->Next != NULL; phim = phim->Next)
        {
            os << phim->Value;
        }
        return os;
    }
    ll &getDS()
    {
        return DS;
    }
};
void a()
{
    QLPhim ql;
    fstream in("bai8_input.txt"); // thay the cho Input.txt;
    ql.themPhim(in);
    in.close();
    fstream out("bai8_output.txt");
    ql.xuatPhim(out);
    out.close();
}
void b(QLPhim &ql, string tenphim, string theloai, string path = "bai8_output.txt")
{
    for (auto phim = ql.getDS().getFirst(); phim->Next != NULL; phim = phim->Next)
    {
        if (phim->Value.getTenPhim() == tenphim)
        {
            phim->Value.setTheLoai(theloai);
        }
    }
    fstream f(path, ios::out, ios::trunc); // if ios_trunc marked, please clear
    ql.xuatPhim(f);
}
void c(QLPhim ql)
{
    ql.xuatPhim(cout);
}
void d(QLPhim ql, string dvnam) // do not turn ql to &ql
// the code require a copy of object, then
// some how using const &ql marked by IDE
// it seems that ql member fns does not takes const parameter, require a new or better syntax declaration
{
    stringstream buffer;
    decltype(ql.getDS().search_before(VIDEO())) it;
    while (it = ql.getDS().search_before(dvnam))
    {
        if (it == NULL)
            break;
        buffer << it->Next->Value;
        it->deleteAfter();
    }
    string path = dvnam + ".txt";
    ofstream of(path);
    of << buffer.str();
    of.close();
}
void e(QLPhim ql)
{
    vector<string> ds_director;
    // quen dung tuple thong ke sl bo phim
    map<string, int> sl;
    map<string, stringstream> director;
    // maintaining a string is better, but i didn't create an alternative to <<;
    for (auto it = ql.getDS().First; it != NULL; it = it->Next)
    {
        auto succeed_create = director.emplace(it->Value.getTenDaoDien(), stringstream());
        succeed_create.first->second << it->Value;
        auto themSL = sl.emplace(it->Value.getTenDaoDien(), 1);
        if (!themSL.second)
        {
            themSL.first->second++;
        }
    }
    for (const auto &it : director)
    {
        string path = it.first + ".txt";
        ofstream of(path, ios::trunc);
        of << "Dao dien " << it.first << ".\n";
        of << "So luong tac pham: " << sl[it.first] << "\n";
        of << "Danh sach: \n";
        of << it.second.str();
        of.close();
    }
}
void f(QLPhim ql)
{
    // get list namsx;
    // tim 3 video moi nhat
    // quy tro lai hoan thanh list;
    vector<VIDEO> ds;

    vector<string> namSX;
    for (auto it = ql.getDS().First; it != NULL; it = it->Next)
    {
        namSX.push_back(it->Value.getNamSX());
    }
    sort(all(namSX), greater<string>());
    namSX.resize(3);
    vector<VIDEO> v;
    auto fn = [&](string nsx)
    {
        for (auto it = ql.getDS().First; it != NULL; it = it->Next)
        {
            if (it->Value.getNamSX() == nsx && find(all(v), it->Value) != v.end())
                return it->Value;
        }
        return VIDEO();
    };

    for (auto nsx : namSX)
    {
        v.push_back(fn(nsx));
    }
    ofstream of("Phimmoi.txt", ios::trunc);
    for (auto vid : v)
    {
        of << vid;
    }
    of.close();
}
int main()
{
    cout << "build success";
}
