#include <bits/stdc++.h>
#define t int
#define ll LinkedList
#define all(v) begin(v), end(v)
using namespace std;
struct Node
{
    Node *Next;
    t Value;
    Node(t value) : Value(value), Next(NULL) {}
    Node(t value, Node *next) : Value(value), Next(next) {}
    static Node *createNode(t value)
    {
        return new Node(value);
    }
    Node *addAfter(t value)
    {
        auto node = createNode(value);
        node->Next = Next;
        Next = node;
        return node;
    }
    void deleteAfter()
    {
        auto tmp = Next;
        Next = Next->Next;
        delete tmp;
    }
};
struct LinkedList
{
    Node *First, *Last;
    LinkedList() : First(NULL), Last(NULL) {}
    Node *addFirst(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            node->Next = First;
            First = node;
        }
        return node;
    }
    Node *addLast(t value)
    {
        auto node = Node::createNode(value);
        if (First == NULL)
        {
            First = node;
            Last = node;
        }
        else
        {
            Last->Next = node;
            Last = node;
        }
        return node;
    }
    Node *move(Node *node, unsigned int k)
    {
        while (k)
        {
            if (node->Next == NULL)
            {
                node = First;
                k--;
            }
            while (k && node->Next != NULL)
            {
                node = node->Next;
                k--;
            }
        }
        return node;
    }
    Node *search(t value)
    {
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Value == value)
                return node;
        }
        return NULL;
    }
    Node *search_before(t value)
    {
        if (First->Value == value)
            return new Node(0, First);
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            if (node->Next->Value == value)
                return node;
        }
        return NULL;
    }
    int getLength()
    {
        int cnt = 0;
        for (Node *node = First; node->Next != NULL; node = node->Next, cnt++)
            ;
        return cnt;
    }
    vector<t> getList()
    {
        vector<t> vec;
        for (Node *node = First; node->Next != NULL; node = node->Next)
        {
            vec.push_back(node->Value);
        }
        return vec;
    }
    void sort()
    {
        for (auto node = First; node->Next != NULL; node = node->Next)
        {
            for (auto walker = node->Next; walker->Next != NULL; walker = walker->Next)
            {
                if (walker->Value < node->Value)
                {
                    t tmp = node->Value;
                    node->Value = walker->Value;
                    walker->Value = tmp;
                }
            }
        }
    }
    void reverse_ll()
    {
        auto vec = getList();

        reverse(begin(vec), end(vec));
        int i = 0;
        for (auto node = First; node->Next != NULL; node = node->Next, i++)
            node->Value = vec[i];
    }
    void deleteFirst()
    {
        auto tmp = First;
        First = First->Next;
        delete tmp;
    }
    ll *operator()(ll x)
    {
        auto l = new ll();
        for (auto it = x.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
    static ll *join(ll a, ll b)
    {
        auto l = new ll();
        for (auto it = a.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        for (auto it = b.First; it->Next != NULL; it = it->Next)
        {
            l->addLast(it->Value);
        }
        return l;
    }
};
ll *a(ll a, ll b)
{
    auto c = ll::join(a, b);
    return c;
}
void b(ll &a, ll c)
{
    auto v = c.getList();
    for (t x : v)
    {
        while (auto it = a.search_before(x))
        {
            if (it == NULL)
                break;
            it->deleteAfter();
        }
    }
}
ll *c(ll a, ll c)
{
    auto v1 = a.getList();
    set<t> s1(all(v1));
    auto v2 = c.getList();
    set<t> s2(all(v2));
    set<t> v3;
    set_intersection(all(s1), all(s2), inserter(v3, v3.begin()));
    auto l = new ll();
    for (auto i : v3)
    {
        l->addLast(i);
    }
    return l;
}
ll *d(ll a, ll c)
{
    auto v1 = a.getList();
    set<t> s1(all(v1));
    auto v2 = c.getList();
    set<t> s2(all(v2));
    set<t> v3;
    set_union(all(s1), all(s2), inserter(v3, v3.begin()));
    auto l = new ll();
    for (auto i : v3)
    {
        l->addLast(i);
    }
    return l;
}
ll *e(ll a, ll c)
{
    auto v1 = a.getList();

    auto v2 = c.getList();
    if (v1.size() < v2.size())
    {
        for (int i = 1; i <= v2.size() - v1.size(); ++i)
            v1.push_back(0);
    }
    else
    {
        for (int i = 1; i <= v1.size() - v2.size(); ++i)
            v2.push_back(0);
    }
    vector<int> v3;
    for (int i = 0; i < v1.size(); ++i)
    {
        v3.push_back(v1[i] + v2[i]);
    }
    auto l = new ll();
    for (auto i : v3)
    {
        l->addLast(i);
    }

    return l;
}
bool f(ll a, ll c)
{
    auto v1 = a.getList();
    auto v2 = c.getList();
    sort(all(v1));
    sort(all(v2));
    if (v1 == v2)
        return 1;
    return 0;
}
bool g(ll &a, ll c)
{
    auto v1 = a.getList();
    auto v2 = c.getList();
    int sum = 0;
    for (auto i : v2)
    {
        sum += i;
    }
    for (int i = 0; i < v1.size(); ++i)
    {
        if (v1[i] > sum)
        {
            auto node = a.First;
            if (i != 0)
            {
                a.move(node, i - 1);
                node->deleteAfter();
            }
            else
            {
                a.deleteFirst();
            }
            return 1;
        }
    }
    return 0;
}
bool h(ll &a, ll c)
{
    auto v1 = a.getList();
    auto v2 = c.getList();
    int sum = 0;
    for (auto i : v2)
    {
        sum += i;
    }
    for (int i = 0; i < v1.size(); ++i)
    {
        if (v1[i] == sum)
        {
            auto node = a.First;
            if (i != 0)
            {
                a.move(node, i - 1);
                node->deleteAfter();
            }
            else
            {
                a.deleteFirst();
            }
            return 1;
        }
    }
    return 0;
}
int main()
{
}